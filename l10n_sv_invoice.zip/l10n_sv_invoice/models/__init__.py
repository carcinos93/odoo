# -*- coding: utf-8 -*-

# from . import l10n_sv_invoice
from . import Empleado
